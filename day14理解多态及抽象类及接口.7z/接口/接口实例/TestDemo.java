package day14理解多态及抽象类及接口.接口.接口实例;

/**
 * 一般情况下，自定义类型进行比较 需要是 可比较 的
 * Comparable 和 Comparator
 */

import java.util.Arrays;

class Student implements Comparable<Student> {
    public String name;
    public int age;
    public int score;

    public Student(String name, int age, int score) {
        this.name = name;
        this.age = age;
        this.score = score;
    }

    // 再Student中implements实现泛型Comparable。然后wind[alt+enter]选择implement mehod实现方法
    @Override
    public int compareTo(Student o) {
        if (this.age > o.age) {//以年龄来比较
            return 1;
        } else if (this.age < o.age) {
            return -1;
        } else {
            return 0;
        }
        //        return 0;
    }
}

public class TestDemo {
    public static void main(String[] args) {
        Student student1 = new Student("bit", 18, 79);
        Student student2 = new Student("gaobo", 29, 70);
        Student student3 = new Student("shasha", 3, 99);
        if (student1.compareTo(student2) > 0) {
            System.out.println("student1的年龄 > student2");
        } else if (student1.compareTo(student2) < 0) {
            System.out.println("student1的年龄 < student2");
        } else {
            System.out.println("student1的年龄 == student2");
        }
        Student[] students = new Student[3];
        students[0] = student1;
        students[1] = student2;
        students[2] = student3;
        Arrays.sort(students);
        System.out.println(Arrays.toString(students));
    }

    public static void main1(String[] args) {
        int[] array = {12, 3, 89, 43, 56};
        Arrays.sort(array);
        System.out.println(Arrays.toString(array));
        int a = 10, b = 20;
    }
}
