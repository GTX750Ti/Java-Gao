package day14理解多态及抽象类及接口.接口.接口实例;

class Animal {
    protected String name;

    public Animal(String name) {
        this.name = name;
    }
}

interface IFlying {
    void fly();
}

interface IRunning {
    void run();
}

interface ISwimming {
    void swim();
}

/*
1.一个类可以继承一个普通类/抽象类，并且可以同时实现多个接口
先 extend 再 implements
 */
class Cat extends Animal implements IRunning {
    public Cat(String name) {
        super(name);
    }

    public void run() {
        System.out.println(this.name + "正在用四条腿跑");
    }
}

class Fish extends Animal implements ISwimming {
    public Fish(String name) {
        super(name);
    }

    public void swim() {
        System.out.println(this.name + "正在尾巴游");
    }
}
class Frog extends Animal implements IRunning, ISwimming{
    public Frog(String name) {
        super(name);
    }
    public void run() {
        System.out.println(this.name + "正在跑");
    }
    public void swim() {
        System.out.println(this.name + "正在游");
    }
}
class Robot implements IRunning{
    @Override
    public void run() {
        System.out.println("我是机器人，正在跑");
    }
}
public class TestMoreExtends {
    public static void walk(IRunning running) {
        System.out.println("我带着伙伴去散步");
        running.run();
    }
    public static void main(String[] args) {
        IRunning iRunning = new Robot();
        iRunning.run();
        walk(iRunning);

        IRunning iRunning1 = new Frog("青青");
        walk(iRunning1);

        ISwimming iSwimming = new Frog("青青");
    }
}
