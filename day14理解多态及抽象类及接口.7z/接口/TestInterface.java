package day14理解多态及抽象类及接口.接口;

/**
 * 接口(Interface)
 * 1.接口当中的方法，都是抽象方法
 * 2.其实可以有具体实现的方法[，这个方法是被default修饰的JDK1.8加入的]
 * 3.接口当中定义的成员变量默认是 常量 一定要赋值，否则会报错
 * 4.接口当中的成员变量默认是: public static final； 成员方法默认是: public abstract
 * 5.接口是不可以被实例化，
 * 6.接口和类的关系
 * 7.接口的出现是为了解决Java单继承问题
 * 8.只要这个类实现了该接口，那么就可以实现向上转型
 */

interface Shape {
    public static final int a = 10;

    public abstract void draw();

    default public void func1() {
        System.out.println("default接口方法");
    }
}

interface A {
}

class Circle implements Shape, A {
    @Override
    public void draw() {
        System.out.println("画⚪");
    }
}

class React implements Shape {
    @Override
    public void draw() {
        System.out.println("画♦");
    }
}

public class TestInterface {
    public static void drawMap(Shape shape) {
        shape.draw();
    }

    public static void main(String[] args) {
        //    Shape shape = new Shape();// 接口是不可以被实例化，
        Shape shape1 = new Circle();
        Shape shape2 = new React();
        drawMap(shape1);
        drawMap(shape2);
    }
}
