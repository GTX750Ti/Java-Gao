package day14理解多态及抽象类及接口.多态;

class Shape {
    protected String name;

    public void draw() {
    }

    public Shape(String name) {
        System.out.println("Shape::name-->");
    }
}

class Cycle extends Shape {
    public Cycle(String name) {
        super(name);
    }

    @Override
    public void draw() {
        System.out.println("画一个圆");
    }
}

class React extends Shape {
    public React(String name) {
        super(name);
    }

    @Override
    public void draw() {
        System.out.println("画一个矩形");
    }
}

class Triangle extends Shape {
    public Triangle(String name) {
        super(name);
    }

    @Override
    public void draw() {
        System.out.println("画一个三角形");
    }
}

public class TestDemo2 {
    /**
     * 什么是多态
     * 1.父类引用 引用子类对象
     * 2.父类和子类有同名的覆盖方法
     * 3.通过父类引用代用这个重写的方法的时候
     *
     * @param shape
     */
    public static void drawMap(Shape shape) {
        shape.draw();
    }

    public static void main(String[] args) {
        Shape shape1 = new Cycle("山地自行车");
        Shape shape2 = new React("矩形方阵");
        Shape shape3 = new Triangle("红色三角");
        /*shape1.draw();
        shape2.draw();*/
        /*
        多态的单个调用
         */
        drawMap(shape1);
        drawMap(shape2);
        drawMap(shape3);
        String[] shapes = {"Cycle", "React", "Triangle", "Cycle"};
        /*
        for循环+if判断实现打印
         */
        for (String v : shapes) {
            if (v.equals("Cycle")) {
                new Cycle("山地自行车").draw();
            }else if (v.equals("React")) {
                new React("矩形").draw();
            }else if (v.equals("Flower")) {
                new Triangle("三角形").draw();
            }
        }

        /*
        通过数组+多态：实现循环打印
         */
        Shape[] shapes1 = {new Cycle("山地行车"), new React("矩形") , new Triangle("三角形")};
        for (Shape v : shapes1) {
            v.draw();
        }
    }
}
