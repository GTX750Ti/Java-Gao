package day14理解多态及抽象类及接口.多态;

class Animal {
    public String name;
    int a = 1;

    public Animal(String name) {
        this.name = name;
    }

    public void eat() {
        System.out.println("Animal" +this.name + "正在吃!");
    }
    public void sleep() {
        System.out.println("Animal" + this.name + "正在睡觉");
    }
}

class Cat extends Animal {
    /*
    1.子类继承了什么？父类中除构造方法之外的全部
    2.子类在构造的时候，一定要帮助父类来先进行公构造
    this: 当前类的引用
    super: 父类的引用
     */
    public String huzi;
    int a = 2;

    public Cat(String name, String huzi) {
        super(name);//帮助父类进行构造
        this.huzi = huzi;//构造自己
    }

    public void eat() {
        System.out.println("正在吃!Cat");
    }
    public void func() {
        System.out.println(this.name);
    }
}

public class TestDemo {
    public static void main(String[] args) {
        //向上转型：父类引用 引用子类对象
        Animal animal = new Cat("初一", "向上转型大胡子");
        animal.eat();
//        animal.huzi;//不能访问子类的

        /*Cat cat = new Cat("咪咪", "大胡子");
        cat.eat();*/
    }
}
