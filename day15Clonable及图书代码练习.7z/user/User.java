package day15Clonable及图书代码练习.user;

import day15Clonable及图书代码练习.book.BookList;
import day15Clonable及图书代码练习.operation.IOperation;

public abstract class User {
    public String name;
    protected IOperation[] operations;

    public User(String name) {
        this.name = name;
    }
    public abstract int menu();
    public void doOperation(BookList bookList, int choice) {
        this.operations[choice].work(bookList);
    }
}
