package day15Clonable及图书代码练习;

import java.util.Arrays;

/**
 * class Person类属于自定义类，没有继承Object，所以没有clone()方法
 * <p>
 * 1.Ctrl+左键点击 Cloneable-->空接口: 也叫标记接口，只要一个类实现了这个接口，那么就标记这个类是可以进行clone的
 * 2.重写clone方法[Wind: Alt+Ins/MacOS: option+Enter 后-->选择clone()]
 * 3.解决person.cloe()依旧报错问题: 鼠标颠倒person.clone()然后Alt+Enter选怎Add Exceptionxxx添加异常到方法区
 * 4.我们发现clone()方法返回值是Object，所以我们需要强制类型转
 */
class Money implements Cloneable {
    double money = 12.5;
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}

class Person implements Cloneable {
    public int age;
    Money m = new Money();

    @Override
    protected Object clone() throws CloneNotSupportedException {
//        return super.clone();
        //1.克隆person
        Person p1 = (Person) super.clone();
        //2.克隆当前的Money对象
        p1.m = (Money) this.m.clone();
        return p1;
    }
}

public class Test {
    public static void main(String[] args) throws CloneNotSupportedException {
        Person person1 = new Person();
        Person person2 = (Person) person1.clone();
        person2.m.money = 99.9;
        System.out.println(person1.m.money);
        System.out.println(person2.m.money);
    }

    public static void main1(String[] args) {
        int[] array1 = {1, 2, 3, 4, 5, 6};
        /**
         * 对于简单类型是深拷贝
         * 对于引用类型是浅拷贝
         *
         * 由于数组是继承Object类，因此才有clone方法
         */
        int[] array2 = array1.clone();
        array2[0] = 99;
        System.out.println(Arrays.toString(array1));
        System.out.println(Arrays.toString(array2));
    }
}
