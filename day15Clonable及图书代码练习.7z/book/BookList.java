package day15Clonable及图书代码练习.book;

public class BookList {
    private Book[] books = new Book[100];
    private int usedSize = 0;

    public BookList() {
        books[0] = new Book("穷查理宝典", "彼得.考夫曼", 168, "理财");
        books[1] = new Book("塑造世界经济的五十项伟大发明", "蒂姆.哈福德", 58, "兴趣");
        books[2] = new Book("影响力", "罗伯特", 45, "心理学");
        this.usedSize = 3;
    }
    public void setBooks(int pos, Book book) {
        this.books[pos] = book;
    }

    public Book getBook(int pos) {
        return this.books[pos];
    }

    public int getUsedSize() {
        return usedSize;
    }

    public void setUsedSize(int usedSize) {
        this.usedSize = usedSize;
    }
}
