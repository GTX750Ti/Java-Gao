package day15Clonable及图书代码练习.operation;

import day15Clonable及图书代码练习.book.Book;
import day15Clonable及图书代码练习.book.BookList;

public class DisplayOperation implements IOperation {
    @Override
    public void work(BookList bookList) {
        System.out.println("显示图书图书");
        for (int i = 0; i < bookList.getUsedSize(); i++) {
            Book book = bookList.getBook(i);
            System.out.println(book);
        }
    }
}
