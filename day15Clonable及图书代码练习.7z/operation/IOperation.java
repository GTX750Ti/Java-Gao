package day15Clonable及图书代码练习.operation;

import day15Clonable及图书代码练习.book.BookList;

public interface IOperation {
    void work (BookList bookList);
}
