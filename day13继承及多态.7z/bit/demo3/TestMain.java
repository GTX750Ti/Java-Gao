package day13继承及多态.bit.demo3;

class Animal {
    protected String name;

    public Animal(String name) {
        this.name = name;
        System.out.println("Animal(String)");
    }

    public void eat() {
        System.out.println(this.name + "Animal::eat()");
    }
}

class Cat extends Animal {
    public int count = 99;

    public Cat(String name) {
        super(name);
        System.out.println("Cat(String)");
    }

    public void eat() {
        /*
         重载: overload
        方法名相同
        参数列表不同(参数的个数+类型)
        返回值不做要求
        同一个类中

        重写: override
        方法名相同
        返回值相同
        参数列表相同
        不同的类-->继承关系上

        注意事项：
        1.需要重写的方法不能是被final修饰的。被final修饰之后，他是密封方法，不可以修改
        2.被重写的方法，访问修饰限定符一定不能是私有的
        3.被重写的方法，子类当中的访问修饰限定夫要大于等与父类的修饰访问限定符【private < default < protected < public
        4.static修饰的方法不能被重写
         */
        System.out.println(this.name + "重写Cat::eat()");
    }
}

class Bird extends Animal {
    public String name;

    public Bird(String name) {
        super(name);
        System.out.println(super.name);
    }

    public void fly() {
        System.out.println(super.name + "Bird::fly()");
    }
}

public class TestMain {
    /*
    多态
    运行时绑定【动态绑定】
    父类引用 引用子类对象，同时 通过父类引用调用同名的覆盖方法
    此时就会发生运行时绑定

    反编译Java代码
    D:\Progam\jetBrains\IDEA\高博\src\com\bit\demo3>javac -encoding utf8 TestMain.java
    D:\Progam\jetBrains\IDEA\高博\src\com\bit\demo3>javap -c TestMain
    警告: 二进制文件TestMain包含com.bit.demo3.TestMain
    Compiled from "TestMain.java"
    public class com.bit.demo3.TestMain {
      public com.bit.demo3.TestMain();
        Code:
           0: aload_0
           1: invokespecial #1                  // Method java/lang/Object."<init>":()V
           4: return

      public static void main(java.lang.String[]);
        Code:
           0: new           #2                  // class com/bit/demo3/Cat
           3: dup
           4: ldc           #3                  // String 咪咪
           6: invokespecial #4                  // Method com/bit/demo3/Cat."<init>":(Ljava/lang/String;)V
           9: astore_1
          10: aload_1
          11: invokevirtual #5                  // Method com/bit/demo3/Animal.eat:()V
          14: return
    }


     1: invokespecial #1                  // Method java/lang/Object."<init>":()V 【运行--》这里代表调用了构造方法】
     11: invokevirtual #5                  // Method com/bit/demo3/Animal.eat:()V 【编译--》代表调用方法了。非静态方法】
     */
    public static void main(String[] args) {
        Animal animal = new Cat("咪咪");
        animal.eat();
    }
}
