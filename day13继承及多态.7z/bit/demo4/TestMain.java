package day13继承及多态.bit.demo4;

class Animal {
    protected String name;

    public Animal(String name) {
        this.name = name;
        System.out.println("Animal(String)");
        eat();
    }

    public void eat() {
        System.out.println(this.name + "Animal::eat()");
    }
}

class Cat extends Animal {
    public int count = 99;

    public Cat(String name) {
        super(name);
        System.out.println("Cat(String)");
    }

    public void eat() {
        System.out.println(this.name + "重写Cat::eat()");
    }
}

class Bird extends Animal {
    public String name;

    public Bird(String name) {
        super(name);
    }

    public void fly() {
        System.out.println(super.name + "Bird::fly()");
    }
}

public class TestMain {
    /*
    一个坑：类的在构造方法中调用时可以发生运行时绑定
     */
    public static void main(String[] args) {
        Cat cat = new Cat("嘻嘻");
//        cat.eat();
    }

    // 不安全的向下转型: 猫不能bird化
    public static void main2(String[] args) {
        Animal animal = new Cat("咪咪");
        /*Bird cat = (Bird) animal;
        cat.fly();*/

        /*
         instance解决
         A instance B
         判断A 是不是 B的一个类
         */
        if (animal instanceof Bird) {
            Bird cat = (Bird) animal;
            cat.fly();
        } else {
            System.out.println("向下转型之间不是同一个类");
        }
    }

    public static void main1(String[] args) {
        /*
        向下转型
        注意：非常不安全，很少使用
         */
        Animal animal = new Bird("八哥");
//        animal.eat();

        // 向下转型-->父类的引用赋值给了子类
        Bird bird = (Bird) animal;
        bird.eat();
        bird.fly();

    }
}