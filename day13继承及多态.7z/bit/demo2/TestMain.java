package day13继承及多态.bit.demo2;

class Animal {
    protected String name;

    public Animal(String name) {
        this.name = name;
        System.out.println("Animal(String)");
    }
    public void eat() {
        System.out.println(this.name + "Animal::eat()");
    }
}

class Cat extends Animal {
    public int count =99;
    public Cat(String name) {
        super(name);
        System.out.println("Cat(String)");
    }
}

class Bird extends Animal {
    public String name;

    public Bird(String name) {
        super(name);
        System.out.println(super.name);
    }
    public void fly() {
        System.out.println(super.name + "Bird::fly()");
    }
}

public class TestMain {

    public static Animal func() {
        Cat cat = new Cat("咪咪");
        return cat;
    }
    public static void main(String[] args) {
        Animal animal = func();
        animal.eat();
    }
    public static void func(Animal animal){
        animal.eat();
    }
    public static void main3(String[] args) {
        Cat cat = new Cat("咪咪");
        func(cat);
    }
    //向上转型
    public static void main2(String[] args) {
        /*
        向上转型: 父类引用 引用子类对象
         */
        Animal animal = new Cat("咪咪");
        animal.eat();
    }
    public static void main1(String[] args) {
        Animal animal = new Animal("豆豆");
        Cat cat = new Cat("咪咪");
//        animal.count;//error: 向上转型之后，通过父类的引用 只能访问父类自己的方法或者属性。父类引用只能访问自己的
    }
}
