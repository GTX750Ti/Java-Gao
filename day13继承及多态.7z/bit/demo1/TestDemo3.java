package day13继承及多态.bit.demo1;

class Test{
    int a;//默认权限-->包访问权限：只能在同一包中访问
}
public class TestDemo3 {
    public static void main(String[] args) {
        TestDemo2 test = new TestDemo2();
    }
}
