package day13继承及多态.bit.demo1;

class Animal {
    protected String name;

    public Animal(String name) {
        this.name = name;
        System.out.println(this.name + "Animal构造方法");
    }

    public void eat(String food) {
        System.out.println(this.name + "正在吃" + food);
    }
}

/**
 * 子类 extends 父类
 * 子类：派生类
 * 父类：基类，超类
 * 1.Java 中使用extends只能单继承[继承一个类]
 * 2.对于父类中的private方法或属性，子类无法访问
 * 3.子类在构造的时候，要先帮助父类构造
 * <p>
 * this()-->调用本类其它的构造方法
 * this.data-->访问当前类当中的属性
 * this.func()-->调用本类的其它成员方法
 * <p>
 * super()-->调用父类的构造方法
 * super.data-->访问父类的属性
 * super.func()-->访问父类的成员方法
 * <p>
 * <p>
 * 切忌继承超过3层
 * 如果不想让此方法被继承，可用final修饰
 * final int a = 0-->常量，只能被初始化一次，接下来就不能再来修改
 * final 修饰类: 密封类 特性：不能被继承。一旦一个类被final修饰，那么这个类必然不能被继承
 * final 修饰方法:
 */
//class Cat extends Animal {
//    public Cat(String name) {
//        super(name);//显式调用
//        super.name = "qiqi";
//        System.out.println(this.name + "Cat(String)");
//    }
//    /*public String name;
//
//    public void eat() {
//        System.out.println(this.name + "Cat::eat()");
//    }*/
//}

class Bird extends Animal {
    public String name;

    public Bird(String name) {
        super(name);
        System.out.println(super.name);
    }

    public void fly() {
        System.out.println(super.name + "正在飞");
    }
}

final class Cat extends Animal {
    public Cat(String name) {
        super(name);
    }
}

public class TestDemo {
    public static void main(String[] args) {
        Bird bird = new Bird("小鸟");
        System.out.println(bird.name);
        bird.fly();
    }
}
