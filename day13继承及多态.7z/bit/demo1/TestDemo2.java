package day13继承及多态.bit.demo1;
class Base{
    public int a;
}
class Driver extends Base{
    public int b;
}
public class TestDemo2 {
    public static void main(String[] args) {
        Driver driver = new Driver();
        TestDemo t = new TestDemo();
        System.out.println(driver.a = 99);
    }
}
