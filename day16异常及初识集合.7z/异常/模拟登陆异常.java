package day16异常及初识集合.异常;

/**
 * 自定义异常最好继承Exception，这样好处是：必须处理这个异常
 */
class UserError extends Exception {
    public UserError(String message) {
        super(message);
    }
}

class PasswordError extends Exception {
    public PasswordError(String message) {
        super(message);
    }
}

public class 模拟登陆异常 {
    private static String userName = "admin";
    private static String password = "123456";

    public static void login(String userName, String password) throws UserError,
            PasswordError {
        if (!模拟登陆异常.userName.equals(userName)) {
            throw new UserError("用户名错误");
        }
        if (!模拟登陆异常.password.equals(password)) {
            throw new PasswordError("密码错误");
        }
        System.out.println("登陆成功");
    }

    public static void main(String[] args) {
        try {
            login("admin", "123456");
        } catch (UserError userError) {
            userError.printStackTrace();
        } catch (PasswordError passwordError) {
            passwordError.printStackTrace();
        }
    }
}
