package day16异常及初识集合.异常;

import java.util.Scanner;

/**
 * Throwable类是Java所有错误和异常的父类
 * Error：由程序员自己解决
 * Exception：由程序解决
 * RuntimeException：运行时异常，非受查异常
 * IO/ClassNotFound/CloneNotSupported：全是编译时异常，受查异常
 */
class Base implements Cloneable {
    public void by_zero() {
        /*
        ArithmeticException: / by zero
         */
        int a = 10 / 0;
        System.out.println(a);
    }

    public void indexOut() {
        /*
        ArrayIndexOutOfBoundsException：异常种类
        3：异常类型
        第一个蓝色部分点击可以跳转到错误部分
         */
        int[] nums = {1, 2, 3};
        try {
            System.out.println(nums[3]);// 如果不捕获，则交给JVM来出处理异常：程序立即停止，不再向下执行
        } catch (ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
            System.out.println("捕获到了数组越界");
        }
        System.out.println("hello");// 捕获后，程序自己处理，继续向下运行
    }

    public void NullPointer() {
        int[] nums = {1, 2, 3};
        nums = null;
        try {
            System.out.println(nums[3]);
        } catch (NullPointerException e) {
            System.out.println("捕获到了空指针异常");
        }
        System.out.println("hello");
    }

    public void ExceptionAll() {
        /*
        由于 Exception 类是所有异常类的父类. 因此可以用这个类型表示捕捉所有异常.
        备注: catch 进行类型匹配的时候, 不光会匹配相同类型的异常对象, 也会捕捉目标异常类型的子类
对象.
        如刚才的代码, NullPointerException 和 ArrayIndexOutOfBoundsException 都是 Exception 的
子类, 因此都能被捕获到
         */
        int[] nums = {1, 2, 3};
        nums = null;
        try {
            System.out.println(nums[3]);
        } catch (Exception e) {// 不建议直接捕获Exception
            System.out.println("Exception全部捕获");
        }
        System.out.println("hello");
    }

    public void Finally() {
        /*
        一段代码可能会抛出多种不同的异常, 不同的异常有不同的处理方式. 因此可以搭配多个 catch 代码块
         finally 表示最后的善后工作
         */
        int[] nums = {1, 2, 3};
        nums = null;
        try {
            System.out.println(nums[3]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("数组下标越界");
        } catch (NullPointerException e) {
            System.out.println("空指针异常");
        } finally {
            System.out.println("finally代码来处理善后操作");
        }
        System.out.println("hello");
    }

    public int ExceptionReturn() {
        int[] nums = {1, 2, 3};
        nums = null;
        try {
            System.out.println(nums[3]);
            return 0;
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("数组下标越界");
            return 1;
        } catch (NullPointerException e) {
            System.out.println("空指针异常");
            return 2;
        } finally {
            System.out.println("finally代码来处理善后操作");
            return 3;// finally 中的代码永远会被执行但不建议在finally中出现return语句
        }
    }

    public void ExceptionScanner() {
        /*
        使用 try...finally... 负责回收资源
        alt+enter:
        Scanner scanner = new Scanner(System.in);
        try {
        */
        try (Scanner scanner = new Scanner(System.in)) {
            int n = scanner.nextInt();
            System.out.println(10 / n);
        } catch (ArithmeticException e) {
            e.printStackTrace();
        }
    }

    public void ExceptionStackUp() {
        /*
        如果本方法中没有合适的处理异常的方式, 就会沿着调用栈向上传递
         */
        int[] nums = {1, 2, 3};
        nums = null;
    }

    public void ExceptionThrow() throws ArithmeticException {// 提前通知调用者会抛出的异常，抛给上层调用者
        /*
        throw xxx你想抛出的异常
         */
        int x = 10;
        int y = 0;
        if (y == 0) {
//            throw new UnsupportedOperationException("y==0-->被除数为0");
            throw new ArithmeticException("y==0-->被除数为0");
        }
        System.out.println(x / y);
    }
}

public class 基础异常抛出方法 {
    public static void main(String[] args) {
//        new Base().by_zero();
//        new Base().indexOut();
//        new Base().NullPointer();
//        new Base().ExceptionAll();
//        new Base().Finally();
//        System.out.println(new Base().ExceptionReturn());

        /*try {
            new Base().ExceptionStackUp();
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("数组下标越界");
        } catch (NullPointerException e) {
            System.out.println("空指针异常");
        } finally {
            System.out.println("finally代码来处理善后操作");
        }*/

//        new Base().ExceptionThrow();
        /*Base base = new Base();
        Base base1 = (Base) base.clone();*/
    }
}
