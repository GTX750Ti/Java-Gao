package day16异常及初识集合.集合;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Map接口 {
    public static void put_get() {
        /*

         */
        Map<String, String> map = new HashMap<>();
        map.put("漩涡", "鸣人");
        map.put("宇智波", "鼬");
        map.put("日向", "雏田");
        map.put("日向", "向日葵");// 会覆盖之前的key值
        System.out.println(map);
        String name = map.get("日向");
        String name2 = map.getOrDefault("漩涡2", "博人");
        System.out.println(name);
        System.out.println(name2);
    }

    public static void containsKey_Value() {
        Map<String, String> map = new HashMap<>();
        map.put("漩涡", "鸣人");
        map.put("宇智波", "鼬");
        map.put("日向", "雏田");
        System.out.println(map.containsKey("日向"));
        System.out.println(map.containsKey("日向2"));
        System.out.println(map.containsValue("雏田"));
        System.out.println(map.containsValue("雏田2"));
    }

    public static void entrySet() {
        Map<String, String> map = new HashMap<>();
        map.put("漩涡", "鸣人");
        map.put("宇智波", "鼬");
        map.put("日向", "雏田");
        Set<Map.Entry<String, String>> set = map.entrySet();
        for (Map.Entry<String, String> v:set){
            System.out.println(v.getKey() + "=>" + v.getValue());
        }
    }

    public static void main(String[] args) {
//        put_get();
//        containsKey_Value();
        entrySet();
    }
}
