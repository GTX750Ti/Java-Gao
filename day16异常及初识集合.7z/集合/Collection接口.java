package day16异常及初识集合.集合;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

public class Collection接口 {
    public static void add() {
        Collection<String> collection = new ArrayList<>();
//        Collection collection1 = new LinkedList();
        collection.add("bit");
        collection.add("Java");
        collection.add("C");
        collection.add("Python");
//        System.out.println(collection);
        for (String v: collection) {
            System.out.println(v);
        }
//        collection.add(1);// 只能放字符串，因为String泛型规定
        Collection<Integer> collection1 = new ArrayList<>();
        collection1.add(1);
        System.out.println(collection1);
    }

    public static void clear() {
        Collection<String> collection = new ArrayList<>();
        collection.add("bit");
        collection.clear();
        System.out.println(collection);
    }

    public static void isEmpty() {
        Collection<String> collection = new ArrayList<>();
        collection.add("bit");
        System.out.println(collection.isEmpty());
        collection.clear();
        System.out.println(collection.isEmpty());
    }

    public static void remove() {
        Collection<String> collection = new ArrayList<>();
        collection.add("bit");
        collection.add("Java");
        collection.remove("bit");
        System.out.println(collection);
    }

    public static void size() {
        Collection<String> collection = new ArrayList<>();
        collection.add("bit");
        System.out.println(collection.size());
        collection.clear();
        System.out.println(collection.size());
    }

    public static void toArray() {
        Collection<String> collection = new ArrayList<>();
        collection.add("bit");
        collection.add("Java");
        Object[] objects = collection.toArray();
        System.out.println(Arrays.toString(objects));
    }
    public static void main(String[] args) {
        add();
//        clear();
//        isEmpty();
//        remove();
//        size();
//        toArray();
    }
}
