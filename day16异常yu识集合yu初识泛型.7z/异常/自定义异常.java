package day16异常yu识集合yu初识泛型.异常;

/**
 * 1.一定要继承一个父类异常
 * 2.RuntimeException：非受查异常
 * 3.Exception：受查异常【编译时期异常】
 */
class MyException extends RuntimeException{
    public MyException() {
        super();
    }

    public MyException(String message) {
        super(message);
    }
}
public class 自定义异常 {
    public static void func(int x) throws MyException{
        if (x == 10) {
            throw new MyException("x==10");
        }
    }
    public static void main(String[] args) {
        try {
            func(10);
        }catch (MyException e) {
            e.printStackTrace();
        }
    }
}
