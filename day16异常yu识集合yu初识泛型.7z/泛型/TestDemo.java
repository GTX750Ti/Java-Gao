package day16异常yu识集合yu初识泛型.泛型;

class Person{

}
public class TestDemo {
    public static void main(String[] args) {
        /*
        //Object 和 int 类型的存储调用
        MyArrayList myArrayList = new MyArrayList();
        myArrayList.add(1);
        myArrayList.add(2);
        int val = (int)myArrayList.getVal(1);
        System.out.println(val);*/

        // 泛型的存储调用
        MyArrayList<Integer> myArrayList = new MyArrayList();
        myArrayList.add(1);
        myArrayList.add(2);
        int val = myArrayList.getVal(1);
        System.out.println(val);

        Person person = new Person();
        System.out.println(person);
        System.out.println(myArrayList);
    }
}
