package day16异常yu识集合yu初识泛型.泛型;

/**
 * T: 只是一个占位符，表示当前类是一个泛型类
 *
 *
 * 泛型的坑：
 * 1.不能 new 泛型类型的数组 可以有： thie.elem = new T[10]，T a = new T[10]
 * 2.简单类型不能作为泛型参数，参数一定要是引用类型
 * 3.泛型类型参数不参与类型的组成
 *
 * 泛型的意义：
 * 1.可以自动进行类型的检查
 * 2.自动进行类型的转换
 *
 * 面试问题：泛型怎么编译的：擦除机制
 * 重要：泛型只是编译时期的一种机制。--》擦除机制：在运行的时候，不存在泛型这种说话，所有的处理军在编译阶段已经处理
 * 擦除机制：在编译阶段，泛型类型被擦除为Object。并不是替换
 * @param <T>
 */
public class MyArrayList<T> {

    /*
    //普普通通数据存储--int
    public int[] elem;
    public int usedSize;
    public MyArrayList() {
        this.elem = new int[10];
        this.usedSize = 0;
    }

    // 默认放到数组最后
    public void add(int val) {
        this.elem[this.usedSize++] = val;
    }
    public int getVal(int pos){
        return this.elem[pos];
    }*/

    /*
    //模拟实现任何数据类型的存储--Object
    public Object[] elem;
    public int usedSize;

    public MyArrayList() {
        this.elem = new Object[10];
        this.usedSize = 0;
    }

    // 默认放到数组最后
    public void add(Object val) {
        this.elem[this.usedSize++] = val;
    }
    public Object getVal(int pos){
        return this.elem[pos];
    }*/

    // 泛型的存储
    public T[] elem;
    public int usedSize;

    public MyArrayList() {
//        this.elem = new T[10];
        this.elem = (T[]) new Object[10];
        this.usedSize = 0;
    }

    // 默认放到数组最后
    public void add(T val) {
        this.elem[this.usedSize++] = val;
    }
    public T getVal(int pos){
        return this.elem[pos];
    }
}
